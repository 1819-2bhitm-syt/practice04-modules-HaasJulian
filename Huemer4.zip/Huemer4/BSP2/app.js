const countdown = require("./countdown");
countdown.setDecrementsPerSecond(3);
countdown.setCountdown(10);
